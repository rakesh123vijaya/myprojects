Python 3.11.4 (tags/v3.11.4:d2340ef, Jun  7 2023, 05:45:37) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
========================= RESTART: C:\rakesh\project.py ========================
5
enter a over1
1 2 3 w 6 4
16 1
enter a over2
2 4 3 w 1 6
32 2
enter a over3
2 6  6 4 1 3
54 2
enter a over4
2 6 3 3 w 4
72 3
enter a over5
w 3 5 4 6 2
92 4
total score: 92 for 4 wicktes
{'virat': 2, 'rohith': 26, 'rakesh': 16, 'vamsi': 32, 'dhoni': 4, 'jaddu': 12, 'hardik': 0, 'gail': 0, 'dube': 0, 'bumra': 0, 'shami': 0}
